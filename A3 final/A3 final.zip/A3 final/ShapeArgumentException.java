public class ShapeArgumentException extends Exception {
    
}